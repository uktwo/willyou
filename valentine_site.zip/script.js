const noButton = document.getElementById("no");
const yesButton = document.getElementById("yes");
const message = document.getElementById("message");

noButton.addEventListener("mouseover", () => {
    noButton.style.position = "absolute";
    noButton.style.top = Math.random() * window.innerHeight + "px";
    noButton.style.left = Math.random() * window.innerWidth + "px";
});

yesButton.addEventListener("click", () => {
    message.innerHTML = "Yay! ❤️ See you on Valentine’s Day!";
});